import React from "react";

export default function LoadingRing() {
    return (
        <div className="lds-ring"><div></div><div></div><div></div><div></div></div>
    )
}
