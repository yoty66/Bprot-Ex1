import React, { useState } from "react";


const ExchangeBox = ({fetchRate ,baseCurrency , targetCurrency, icon})=>{

        const [baseValue , setBaseValue ] = useState (0);
        const [targetValue , setTargetValue ] = useState (0);
        const convert = ()=> fetchRate().then(exhRate =>setTargetValue(exhRate * baseValue ))
    return(
        <div className={'currency-box-container'} >
            <div className="currency-box">
                <div className={"currency-box-close" }>
                </div>
                <div className="currency-meta">
                    <div className="currency-icon"><img src={icon} /></div>
                    <div className="currency-value"  style={{textAlign: 'left' , marginLeft:20 ,width:'100%'}} >

                        <div className="currency-title" style={{  display:"flex" , marginBottom:"15px"}}>
                           <p style={{ display:"inline", align:"left",  }}>
                            {baseCurrency}:
                           </p>
                            <div style={{   align:"center",
                                width:"100%", display:"flex",

                                justifyContent: "center" }}>

                            <input  style={{
                                fontFamily: "NeueHaasGroteskDisp Pro Md",
                                fontSize: "20px",
                                letterSpacing: "1.1px",
                                marginTop: "-4px",
                                padding:'2px',
                                border:'2px solid #ccc;',
                                '-webkit-border-radius': '5px',
                                borderRadius: '5px',
                                textAlign:'center',
                               }} type={'text'} onChange={e =>setBaseValue(e.target.value)} value ={baseValue}/>
                            </div>
                            </div>

                        <div className="currency-title"  style={{  display:"flex" ,}}>
                            <p style={{ display:"inline", align:"left", }}>
                            {targetCurrency}:
                            </p>

                            <div style={{width: "100%", textAlign:"center" }}>
                                {targetValue}
                            </div>

                        </div>



                    </div>
                </div>

            <div className="currency-actions">
                <button className="currency-action-button"  onClick={convert}>Convert</button>
            </div>

            </div>
        </div>
    )

}


export default ExchangeBox;