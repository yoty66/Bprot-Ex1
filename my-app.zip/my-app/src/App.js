import React, {useState} from 'react';
import './App.css';
import {getLiquidationPrice} from "./interview";

const App = ()=> {

        const [userAddress, setUserAddress] = useState("");
        const [liquidationPrice, setLiquidationPrice] = useState("");


        const handleSubmit = (evt) => {
            evt.preventDefault();
            alert(`Submitting Name ${userAddress}`)
            setLiquidationPrice("")
            getLiquidationPrice(userAddress).then(price =>setLiquidationPrice(price) )
        }
        return (
            <React.Fragment>

            <form onSubmit={handleSubmit}>
                <label>
                    User Address:
                    <input
                        type="text"
                        value={userAddress}
                        onChange={e => setUserAddress(e.target.value)}
                    />
                </label>
                <input type="submit" value="Submit" />
            </form>
                {liquidationPrice && `liquidationPrice: ${liquidationPrice}`}
            </React.Fragment>
        );
    }


export default App;
